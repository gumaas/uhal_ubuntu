/* A Bison parser, made by GNU Bison 2.7.12-4996.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_VHDLSCANNERYY_VHDLPARSER_H_INCLUDED
# define YY_VHDLSCANNERYY_VHDLPARSER_H_INCLUDED
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int vhdlscannerYYdebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     t_ABSTRLIST = 258,
     t_CHARLIST = 259,
     t_DIGIT = 260,
     t_STRING = 261,
     t_LETTER = 262,
     t_ACCESS = 263,
     t_AFTER = 264,
     t_ALIAS = 265,
     t_ALL = 266,
     t_AND = 267,
     t_ARCHITECTURE = 268,
     t_ARRAY = 269,
     t_ASSERT = 270,
     t_ATTRIBUTE = 271,
     t_BEGIN = 272,
     t_BLOCK = 273,
     t_BODY = 274,
     t_BUFFER = 275,
     t_BUS = 276,
     t_CASE = 277,
     t_COMPONENT = 278,
     t_CONFIGURATION = 279,
     t_CONSTANT = 280,
     t_DISCONNECT = 281,
     t_DOWNTO = 282,
     t_ELSE = 283,
     t_ELSIF = 284,
     t_END = 285,
     t_ENTITY = 286,
     t_EXIT = 287,
     t_FILE = 288,
     t_FOR = 289,
     t_FUNCTION = 290,
     t_GENERATE = 291,
     t_GENERIC = 292,
     t_GUARDED = 293,
     t_IF = 294,
     t_IN = 295,
     t_INOUT = 296,
     t_IS = 297,
     t_LABEL = 298,
     t_LIBRARY = 299,
     t_LINKAGE = 300,
     t_LOOP = 301,
     t_MAP = 302,
     t_NAND = 303,
     t_NEW = 304,
     t_NEXT = 305,
     t_NOR = 306,
     t_NULL = 307,
     t_OF = 308,
     t_ON = 309,
     t_OPEN = 310,
     t_OR = 311,
     t_OTHERS = 312,
     t_OUT = 313,
     t_PACKAGE = 314,
     t_PORT = 315,
     t_PROCEDURE = 316,
     t_PROCESS = 317,
     t_RANGE = 318,
     t_RECORD = 319,
     t_REGISTER = 320,
     t_REPORT = 321,
     t_RETURN = 322,
     t_SELECT = 323,
     t_SEVERITY = 324,
     t_SIGNAL = 325,
     t_SUBTYPE = 326,
     t_THEN = 327,
     t_TO = 328,
     t_TRANSPORT = 329,
     t_TYPE = 330,
     t_UNITS = 331,
     t_UNTIL = 332,
     t_USE = 333,
     t_VARIABLE = 334,
     t_WAIT = 335,
     t_WHEN = 336,
     t_WHILE = 337,
     t_WITH = 338,
     t_XOR = 339,
     t_IMPURE = 340,
     t_PURE = 341,
     t_GROUP = 342,
     t_POSTPONED = 343,
     t_SHARED = 344,
     t_XNOR = 345,
     t_SLL = 346,
     t_SRA = 347,
     t_SLA = 348,
     t_SRL = 349,
     t_ROR = 350,
     t_ROL = 351,
     t_UNAFFECTED = 352,
     t_ASSUME_GUARANTEE = 353,
     t_ASSUME = 354,
     t_CONTEXT = 355,
     t_COVER = 356,
     t_DEFAULT = 357,
     t_FAIRNESS = 358,
     t_FORCE = 359,
     t_INERTIAL = 360,
     t_LITERAL = 361,
     t_PARAMETER = 362,
     t_PROTECTED = 363,
     t_PROPERTY = 364,
     t_REJECT = 365,
     t_RELEASE = 366,
     t_RESTRICT = 367,
     t_RESTRICT_GUARANTEE = 368,
     t_SEQUENCE = 369,
     t_STRONG = 370,
     t_VMODE = 371,
     t_VPROP = 372,
     t_VUNIT = 373,
     t_SLSL = 374,
     t_SRSR = 375,
     t_QQ = 376,
     t_QGT = 377,
     t_QLT = 378,
     t_QG = 379,
     t_QL = 380,
     t_QEQU = 381,
     t_QNEQU = 382,
     t_GESym = 383,
     t_GTSym = 384,
     t_LESym = 385,
     t_LTSym = 386,
     t_NESym = 387,
     t_EQSym = 388,
     t_Ampersand = 389,
     t_Minus = 390,
     t_Plus = 391,
     MED_PRECEDENCE = 392,
     t_REM = 393,
     t_MOD = 394,
     t_Slash = 395,
     t_Star = 396,
     MAX_PRECEDENCE = 397,
     t_NOT = 398,
     t_ABS = 399,
     t_DoubleStar = 400,
     t_Apostrophe = 401,
     t_LeftParen = 402,
     t_RightParen = 403,
     t_Comma = 404,
     t_VarAsgn = 405,
     t_Colon = 406,
     t_Semicolon = 407,
     t_Arrow = 408,
     t_Box = 409,
     t_Bar = 410,
     t_Dot = 411,
     t_Q = 412,
     t_At = 413,
     t_Neg = 414,
     t_LEFTBR = 415,
     t_RIGHTBR = 416,
     t_ToolDir = 417
   };
#endif


#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE vhdlscannerYYlval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int vhdlscannerYYparse (void *YYPARSE_PARAM);
#else
int vhdlscannerYYparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int vhdlscannerYYparse (void);
#else
int vhdlscannerYYparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_VHDLSCANNERYY_VHDLPARSER_H_INCLUDED  */
