/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/

dojo.provide("dojo.xml.svgUtil");
// FIXME: add imports for deps!

dojo.xml.svgUtil = new function(){

	this.getInnerWidth = function(node){
		// FIXME: need to find out from dylan how to 
	}

	this.getOuterWidth = function(node){
		
	}

	this.getInnerHeight = function(node){
		
	}

	this.getOuterHeight = function(node){
		
	}

}
